  nohup matlab -nodisplay -nodesktop -nosplash < $1 > $2 &
