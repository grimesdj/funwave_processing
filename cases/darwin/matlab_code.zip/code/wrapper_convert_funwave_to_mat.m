% currently working on runs in:
runDay = 'AGU2024';
% for all cases archive but don't delete the following vars:
rmfiles = 0;
vars = {'dep','eta','u','v','mask','nubrk','p','q'};
%
%
%%%%%%%% first process the full runs: %%%%%%%%%%%%%%%
runID = 'full';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.rootSim,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.rootOut,[info.rootMat,info.rootName],vars,t,dT,1,1,rmfiles,300)
%
%
runID = 'narrow';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.rootSim,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.rootOut,[info.rootMat,info.rootName],vars,t,dT,1,1,rmfiles,300)
%
%
%
runID = 'uniform';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.rootSim,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.rootOut,[info.rootMat,info.rootName],vars,t,dT,1,1,rmfiles,300)
%
%
%
%%%%%%%% second process the first 30s of each run: %%%%%%%%%%%%%%%
runID = 'full';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.first30sOut,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.first30sOut,[info.rootMat,info.rootName,'first30sec_'],vars,t,dT,1,1,rmfiles,300)
%
%
runID = 'uniform';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.first30sOut,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.first30sOut,[info.rootMat,info.rootName,'first30sec_'],vars,t,dT,1,1,rmfiles,300)
%
runID = 'narrow';
info  = run_info_MOD(runDay,runID);
%
% load the output times and dts
info.timeFile = [info.first30sOut,'time_dt.out'];
save(info.fileName,'info')
Tdt = load(info.timeFile);
t   = Tdt(:,1);
dt  = gradient(t);
dT  = Tdt(:,2); clear Tdt
%
fLog = convert_funwave_output_to_mat(info.first30sOut,[info.rootMat,info.rootName,'first30sec_'],vars,t,dT,1,1,rmfiles,300)
